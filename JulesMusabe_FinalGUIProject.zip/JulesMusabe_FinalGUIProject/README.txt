PocketHR application is an employee management application.
It allows a user to schedule an employee for a select 
number of hours every weekend. Then, a user can display 
the total hours the employee is schduled for.

Note:

Default credentials
username: james
password: ved234