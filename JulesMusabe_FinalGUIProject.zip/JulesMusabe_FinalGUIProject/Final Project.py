#Jules Musabe
#PocketHR 1.0
#An employee management software
 
from breezypythongui import EasyFrame
from tkinter import PhotoImage, N, S, W, E
from tkinter.font import Font
from tkinter import *
from tkinter import ttk
from functools import partial
import tkinter as tk



class ImageDemo(EasyFrame):
    """Displays Welcome window."""
 
    def __init__(self):
        """Sets up the window and widgets."""
        EasyFrame.__init__(self, title = "PocketHR 1.0")
        imageLabel = self.addLabel(text = "",
                                   row = 0, column = 0,
                                   sticky = N+S+W+E)

        # add the start button
        self.addButton(text = "Start", row = 12, column = 0, command = self.master.destroy)
        
        # Load the image
        self.image = PhotoImage(file = "logopicture.gif")
        imageLabel["image"] = self.image
 

#Instantiate and pop up the window.
ImageDemo().mainloop()


#Pull up the program

def validateLogin(username, password):
    
    #Authenticate user
    
    if username.get() == user1 and password.get() == pass1:
        
        #Close the login page
        
        tkWindow.destroy()



        class MenuDemo(EasyFrame):
            """Allows the user to place a restaurant order from a set
            of options."""
            
            def __init__(self):
                
                """Set up the home page"""
                EasyFrame.__init__(self, "Menu Demo")
                
                self.setResizable(True)

                EasyFrame.__init__(self, title = "PocketHR by Jules")
                
                imageLabel = self.addLabel(text = "",
                                           row = 0, column = 0,
                                           columnspan = 2,
                                           sticky = N+S+W+E)
                """Display manager's profile picture"""
                self.image = PhotoImage(file = "managerpicture.gif")
                
                imageLabel["image"] = self.image

                """Set up welcome message for the manager's dashboard"""
                
                textLabel1 = self.addLabel(text = "Welcome",
                                  row = 0, column = 2, columnspan = 2,
                                  sticky = N+S+W+E)

                textLabel2 = self.addLabel(text = "Select employees",
                                  row = 2, column = 0, columnspan = 4, sticky = N+S+W+E)


                

                """Set font and color of the welcome message."""
                font = Font(family = "Verdana", size = 15, slant = "italic")
                textLabel1["font"] = font
                textLabel1["foreground"] = "black"


                font = Font(family = "Verdana", size = 13, slant = "italic")
                textLabel2["font"] = font
                textLabel2["foreground"] = "black"
                

                """Allow manager to select employee he wants to schedule"""
                self.addButton(text = "John", row = 3, column = 1, command = self.employee)

                self.addButton(text = "Mary", row = 3, column = 2, command = self.employee)
                
                self.addButton(text = "Steve", row = 3, column = 3, command = self.employee)

                self.addButton(text = "Quit", row = 3, column = 4, command = self.master.destroy)

                

            def employee(self):
                """Load the scheduling windows"""
                
                class Scheduling(EasyFrame):
                    
                    def __init__(self):
                        
                        EasyFrame.__init__(self, "Schedules")

                        """Place the days and shifts to choose from"""
                        self.addLabel(text = "Saturday", row = 0, column = 1)
                        
                        self.addLabel(text = "Sunday", row = 0, column = 2)
                        
                        self.addLabel(text = "1st Shift", row = 1, column = 0)
                        
                        self.addLabel(text = "2nd Shift", row = 2, column = 0)
                        
                        self.addLabel(text = "3rd Shift", row = 3, column = 0)



                        """Place input fields"""
                        self.SatAM = self.addIntegerField(value=0,row=1,column=1,
                                             width=2)
                        
                        self.SunAM = self.addIntegerField(value=0,row=1,column=2,
                                             width=2)
                        
                        self.SatPM = self.addIntegerField(value=0,row=2,column=1,
                                             width=2)
                        
                        self.SunPM = self.addIntegerField(value=0,row=2,column=2,
                                             width=2)
                        
                        self.SatOverNight = self.addIntegerField(value=0,row=3,column=1,
                                             width=2)
                        
                        self.SunOverNight = self.addIntegerField(value=0,row=3,column=2,
                                             width=2)


                        """The Schedule button that calculates all the hours an employee is scheduled"""
                        self.addButton(text = "Schedule", row = 4, column = 0, command = self.scheduleDisplay)


                        """Display the results"""
                        self.addLabel(text = "Total Hours: ",  row = 5, column =0)
                        
                        self.Outputfield = self.addIntegerField(value=0,row=5,column=1,
                                             width=8,
                                             state="readonly")


                        """Shedule display function"""
                    def scheduleDisplay(self):
                        
                        try:
                            
                            hours = (self.SatAM.getNumber()+ self.SatPM.getNumber()+ self.SatOverNight.getNumber()+ self.SunAM.getNumber()+
                                             self.SunPM.getNumber()+ self.SunOverNight.getNumber())
                            
                            self.Outputfield.setNumber(hours)

                            """Input Validation"""
                            
                        except ValueError:
                            
                                self.messageBox(title="ERROR", message="must be a number")

                            
                if __name__ == "__main__":
                    Scheduling().mainloop()
                        



        # Instantiate and pop up the window."""
        if __name__ == "__main__":
            MenuDemo().mainloop()



      
    else:
        """If user fails to authenticate"""
        import tkinter as tk

        root = Tk()
        root.geometry("100x60")
        root.title("Error")
        message = Label(root,text="Invalid Credentials").grid(row=1, column=0, columnspan = 3)
        btn = Button(root, text='Okay', command=root.destroy).grid(row=2, column=1)
       

        root.mainloop()




"""Login window set up"""        
tkWindow = Tk()  
tkWindow.geometry('400x150')  
tkWindow.title('PocketHR')

"""Setting up default credentials"""
usernameLabel = Label(tkWindow, text="Username").grid()
user1 = 'james'
username = StringVar()
usernameEntry = Entry(tkWindow, textvariable=username).grid(row=0, column=1)  

passwordLabel = Label(tkWindow,text="Password").grid(row=1, column=0)  
pass1 = 'ved234'
password = StringVar()
passwordEntry = Entry(tkWindow, textvariable=password, show='*').grid(row=1, column=1)  

validateLogin = partial(validateLogin, username, password)

#login button
loginButton = Button(tkWindow, text="Login", command=validateLogin).grid(row=4, column=0)  

tkWindow.mainloop()
